// Church AI assistant. Needs the ANTHROPIC_API_KEY environment variable set in Netlify (church-owned key).
const fs=require('fs'),path=require('path');
const DN=['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
const f12=t=>{let[h,m]=t.split(':').map(Number);const a=h>=12?'PM':'AM';h=h%12||12;return h+':'+String(m).padStart(2,'0')+' '+a};
function readJSON(n){for(const d of [path.resolve(__dirname,'../../content'),path.join(process.cwd(),'content'),path.join(process.env.LAMBDA_TASK_ROOT||'.','content')]){try{return JSON.parse(fs.readFileSync(path.join(d,n),'utf8'))}catch(e){}}return{}}
const H={'Content-Type':'application/json'},R=(c,o)=>({statusCode:c,headers:H,body:JSON.stringify(o)});
function context(){
  const S=readJSON('site.json'),K=readJSON('knowledge.json'),C=S.contact||{};
  const L=[];
  L.push('Current time in Abuja: '+new Date().toLocaleString('en-GB',{timeZone:'Africa/Lagos'}));
  L.push('ABOUT: '+(K.about||''));
  L.push('WEEKLY SCHEDULE:\n'+(S.schedule||[]).map(x=>`${DN[x.d]}: ${x.n}, ${f12(x.s)} to ${f12(x.e)}`).join('\n'));
  L.push('MOUNTAIN EXPERIENCE 2026 (special programme, not part of the weekly schedule): Theme Total Recovery. 3rd to 6th December 2026. Opening service Thursday 3rd December 6:00 PM. Backing scripture 1 Samuel 30:8. Venue: Beside Bakery, Kabusa, Abuja. Sessions:\n'+(S.sessions||[]).map(x=>`${x.l}: ${x.date} ${x.time?f12(x.time):'time to be announced'}`).join('\n')+'\nLivestream is on the Watch live page of this website.');
  L.push('GIVING: categories: '+(S.giving||[]).join(', ')+'. '+(S.payNote||'')+'\n'+(S.banks||[]).map(b=>`${b.bank}, ${b.name}, account number ${b.number}`).join('\n'));
  L.push('CONTACT: WhatsApp/phone: '+(C.phones||[]).join(', ')+'. Address: '+(C.address||'')+'. Social: '+(C.socials||[]).map(s=>s.n+' '+s.u).join(', '));
  L.push('FAQ:\n'+(K.faqs||[]).map(f=>`Q: ${f.q}\nA: ${f.a}`).join('\n'));
  return L.join('\n\n')+'\n\nRULES: '+(K.rules||'');
}
exports.handler=async(event)=>{
  if(event.httpMethod!=='POST')return R(405,{error:'POST only'});
  const key=process.env.ANTHROPIC_API_KEY;
  if(!key)return R(503,{error:'not_configured'});
  let msgs;try{msgs=JSON.parse(event.body||'{}').messages}catch(e){return R(400,{error:'bad_request'})}
  msgs=(Array.isArray(msgs)?msgs:[]).slice(-10).map(m=>({role:m&&m.role==='assistant'?'assistant':'user',content:String(m&&m.content||'').slice(0,600)})).filter(m=>m.content);
  while(msgs.length&&msgs[0].role!=='user')msgs.shift();
  if(!msgs.length||msgs[msgs.length-1].role!=='user')return R(400,{error:'bad_request'});
  const system='You are the friendly website assistant of Upon Mount Zion Deliverance Gospel Ministry (UMZDGM), Kabusa, Abuja. Be warm, brief and clear. Use only the church information below; never invent times, numbers, accounts or events. If something is not covered, say you are not sure and point to the WhatsApp numbers.\n\n'+context();
  try{
    const r=await fetch('https://api.anthropic.com/v1/messages',{method:'POST',headers:{'content-type':'application/json','x-api-key':key,'anthropic-version':'2023-06-01'},body:JSON.stringify({model:process.env.ANTHROPIC_MODEL||'claude-sonnet-5-5',max_tokens:500,system,messages:msgs})});
    if(!r.ok)return R(502,{error:'upstream_'+r.status});
    const d=await r.json();
    const reply=(d.content||[]).filter(b=>b.type==='text').map(b=>b.text).join('\n').trim();
    return reply?R(200,{reply}):R(502,{error:'empty'});
  }catch(e){return R(502,{error:'network'})}
};
